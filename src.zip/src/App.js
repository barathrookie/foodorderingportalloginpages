import React from 'react';
// import '/.login.css';

import './App.css';
import Login from './pages/login';
function App() {
  return (
    <Login/>

    
  

  
    
  );
}

export default App;